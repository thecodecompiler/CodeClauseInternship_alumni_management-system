 <!-- Masthead-->
         <img class="img" src="admin/assets/uploads/UMP.jpg"  width="100%" > 
      <hr class="divider my-4" />   	<center> <h4 class="text-uppercase text-black font-weight-bold">About Us</h4></center
     
          <div class="container">
 <hr class="divider my-4" />   <?php echo html_entity_decode($_SESSION['system']['about_content']) ?>        
            
        </div>
       